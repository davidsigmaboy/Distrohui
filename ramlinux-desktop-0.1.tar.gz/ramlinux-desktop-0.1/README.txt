RamLinux desktop 0.1
====================

A framebuffer desktop for the Linux console (the same one RamLinux uses).
It is NOT an X11 or Wayland desktop: it draws straight into /dev/fb0,
so it runs on a text console, like the console UI of a minimal system.

What is inside
  gui      the desktop: icons, app launcher, Pong
  gweb     graphical text browser (HTTP; HTTPS is not supported yet)
  fm       file manager
  open     start an app from the shell, or open a web address: open web / open http://...
  appget   install app packages (.tar.gz) from a URL: appget URL, appget -r NAME
  ramdesk  starts the desktop with checks for /dev/fb0
  /opt/apps/*.conf   the desktop icons. Each app is one .conf file:
                     name=, label=, color=R,G,B, run=  (run=@pong is the built-in game)

Install (any x86_64 Linux with a framebuffer)
  sudo sh install.sh
  Then on a text console (Ctrl+Alt+F2) run:  ramdesk

Needs
  - a kernel with framebuffer support (efifb / vesafb / simpledrm / drm fbdev emulation)
  - root or membership in the video group for /dev/fb0
  - wget and tar for appget, awk for the web browser, sh for the shell app

Keys
  Desktop: arrows select, Enter opens, r reloads apps, q quits to the console
  Browser: g address, digits + Enter follow a link, b back, r reload, q to desktop

Adding apps
  Put a .conf file into /opt/apps, or install a package with appget.
  Package = .tar.gz with one folder NAME/ containing app.conf and the program.

Not included
  The RamLinux book and logo tools (they need busybox), the installer, and the kernel.
