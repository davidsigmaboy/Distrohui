# render.awk — HTML -> текст. Вход: одна строка (\n заменены на \001).
# awk -v base=URL -v linkfile=ФАЙЛ -f render.awk

function dec(t,    n, c) {
    if (index(t, "&") == 0) return t
    gsub(/&nbsp;/, " ", t); gsub(/&lt;/, "<", t); gsub(/&gt;/, ">", t)
    gsub(/&quot;/, "\"", t); gsub(/&apos;|&#39;|&#x27;/, "'", t)
    gsub(/&mdash;|&ndash;/, "-", t); gsub(/&hellip;/, "...", t)
    gsub(/&laquo;/, "<<", t); gsub(/&raquo;/, ">>", t); gsub(/&copy;/, "(c)", t)
    while (match(t, /&#[0-9][0-9]*;/)) {
        n = substr(t, RSTART + 2, RLENGTH - 3) + 0
        c = (n >= 32 && n < 127 && n != 38) ? sprintf("%c", n) : "?"
        t = substr(t, 1, RSTART - 1) c substr(t, RSTART + RLENGTH)
    }
    gsub(/&amp;/, "\\&", t)
    return t
}

function attr(t, n,    r, v) {
    r = tolower(t)
    if (match(r, n "[ ]*=[ ]*\"")) { v = substr(t, RSTART + RLENGTH); sub(/".*/, "", v); return v }
    if (match(r, n "[ ]*=[ ]*'")) { v = substr(t, RSTART + RLENGTH); sub(/'.*/, "", v); return v }
    if (match(r, n "[ ]*=[ ]*[^ >]")) { v = substr(t, RSTART + RLENGTH - 1); sub(/[ ].*/, "", v); return v }
    return ""
}

function resolve(h) {
    gsub(/&amp;/, "\\&", h)
    gsub(/^[ ]+|[ ]+$/, "", h)
    if (h == "" || h ~ /^#/ || h ~ /^javascript:/ || h ~ /^mailto:/ || h ~ /^tel:/) return ""
    if (h ~ /^https?:\/\//) return h
    if (h ~ /^\/\//) return (scheme == "") ? "" : scheme ":" h
    if (h ~ /^\//) return origin h
    if (dir == "") return ""
    while (h ~ /^\.\//) h = substr(h, 3)
    return dir h
}

function emit(t) {
    if (inpre) gsub(/\001/, "\n", t); else gsub(/\001/, " ", t)
    t = dec(t)
    if (intitle) { title = title t; return }
    if (!inpre) gsub(/  +/, " ", t)
    printf "%s", t
}

BEGIN {
    b = base; sub(/#.*/, "", b)
    i = index(b, "://")
    if (i > 0) {
        scheme = substr(b, 1, i - 1); rest = substr(b, i + 3); sub(/[?].*/, "", rest)
        sl = index(rest, "/")
        host = sl ? substr(rest, 1, sl - 1) : rest
        path = sl ? substr(rest, sl) : "/"
        origin = scheme "://" host
        n = split(path, pp, "/"); dir = origin
        for (k = 2; k < n; k++) dir = dir "/" pp[k]
        dir = dir "/"
    }
    if (i == 0 && substr(b, 1, 1) == "/") {
        origin = ""
        n = split(b, pp, "/"); dir = ""
        for (k = 2; k < n; k++) dir = dir "/" pp[k]
        dir = dir "/"
    }
    nl = 0
}

{
    s = $0
    while ((i = index(s, "<")) > 0) {
        emit(substr(s, 1, i - 1))
        s = substr(s, i)
        if (substr(s, 1, 4) == "<!--") {
            j = index(s, "-->"); if (!j) { s = ""; break }
            s = substr(s, j + 3); continue
        }
        j = index(s, ">"); if (!j) { s = ""; break }
        tag = substr(s, 2, j - 2); s = substr(s, j + 1)
        name = tolower(tag); closing = (substr(name, 1, 1) == "/")
        sub(/^\//, "", name); sub(/[ \/].*/, "", name)

        if (name == "script" || name == "style" || name == "noscript") {
            if (!closing) { k = index(tolower(s), "</" name); s = k > 0 ? substr(s, k) : "" }
            continue
        }
        if (name == "title") {
            if (closing) { intitle = 0; gsub(/^ +| +$/, "", title); if (title != "") printf "== %s ==\n\n", title; title = "" }
            else intitle = 1
        }
        else if (name == "br") printf "\n"
        else if (name == "pre") { inpre = !closing; printf "\n" }
        else if (name ~ /^h[1-6]$/) { if (closing) printf "\n\n"; else printf "\n\n%s ", (name == "h1" || name == "h2") ? "#" : "##" }
        else if (name == "p" || name == "ul" || name == "ol" || name == "table" || name == "blockquote") printf "\n\n"
        else if (name == "div" || name == "section" || name == "article" || name == "header" || name == "footer" || \
                 name == "nav" || name == "main" || name == "aside" || name == "form" || name == "tr" || name == "dl" || \
                 name == "dt" || name == "dd" || name == "figure" || name == "center" || name == "details" || name == "summary") printf "\n"
        else if (name == "li") { if (!closing) printf "\n * "; else printf "\n" }
        else if (name == "td" || name == "th") { if (!closing) printf " | " }
        else if (name == "hr") printf "\n--------------------\n"
        else if (name == "img") { a = attr(tag, "alt"); if (a != "") printf "[img: %s]", dec(a) }
        else if (name == "a") {
            if (!closing) {
                u = resolve(attr(tag, "href"))
                if (u != "") { nl++; print nl, u > linkfile; cur = nl } else cur = 0
            } else if (cur) { printf "[%d]", cur; cur = 0 }
        }
    }
    emit(s)
    printf "\n"
}

END { if (linkfile != "") close(linkfile) }
