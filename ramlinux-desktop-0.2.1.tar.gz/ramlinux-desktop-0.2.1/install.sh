#!/bin/sh
# Installs the RamLinux desktop into the running system. Run as root: sudo sh install.sh
set -e
D=$(cd "$(dirname "$0")" && pwd)
if [ "$(id -u)" != 0 ]; then
    echo "run as root: sudo sh install.sh"
    exit 1
fi
for f in gui gweb fm open appget ramdesk; do
    install -m 755 "$D/usr/local/bin/$f" /usr/local/bin/$f
done
install -d /usr/share/gui /usr/share/web /opt/apps
install -m 644 "$D/usr/share/gui/font8x16.bin" /usr/share/gui/font8x16.bin
for f in "$D"/usr/share/web/*; do install -m 644 "$f" /usr/share/web/; done
for f in "$D"/opt/apps/*.conf; do install -m 644 "$f" /opt/apps/; done
echo "RamLinux desktop installed."
echo "Switch to a text console (Ctrl+Alt+F2), log in and run: ramdesk"
